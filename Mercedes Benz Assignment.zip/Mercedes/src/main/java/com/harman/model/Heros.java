package com.harman.model;

import java.util.Comparator;
import java.util.Objects;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonProperty;

@Component
public class Heros implements Comparable<Heros> {

	@JsonProperty("name")
	String name;
	@JsonProperty("max_power")
	int max_power;

	int count = 1;

	public Heros(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		return Objects.hash(count, max_power, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Heros other = (Heros) obj;
		return max_power == other.max_power && Objects.equals(name, other.name);
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@JsonProperty("character")
	String character;

	public Heros() {
		// TODO Auto-generated constructor stub
	}

	public Heros(String name, int max_power) {
		super();
		this.name = name;
		this.max_power = max_power;

	}

	public Heros(String name, int max_power, int count) {
		super();
		this.name = name;
		this.max_power = max_power;
		this.count = count;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMax_power() {
		return max_power;
	}

	public void setMax_power(int max_power) {
		this.max_power = max_power;
	}

	@Override
	public String toString() {
		return "Heros [name=" + name + ", max_power=" + max_power + ", count=" + count + "]";
	}

	@Override
	public int compareTo(Heros o) {

		return this.count - o.getCount();
	}

	public static Comparator<Heros> powerComparator  = new Comparator<Heros>() {
		
		public int compare(Heros o1,Heros o2) {
			int power1 = o1.getMax_power();
			int power2 = o2.getMax_power();
			return power1-power2;
		}
	};

}
