package com.harman.model;

import java.util.Objects;

public class FavHeros implements Comparable<FavHeros>{

	String name;
	int max_power;
	int count=0;
	
	public FavHeros() {
		// TODO Auto-generated constructor stub
	}

	public FavHeros(String name, int max_power, int count) {
		super();
		this.name = name;
		this.max_power = max_power;
		this.count = count;
	}

	public FavHeros(String name) {
		this.name = name;
	}
	

	public FavHeros(String name, int max_power) {
		super();
		this.name = name;
		this.max_power = max_power;
	
	}

	public String getName() {
		return name;
	}

	@Override
	public int hashCode() {
		return Objects.hash(count, max_power, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FavHeros other = (FavHeros) obj;
		return count == other.count && max_power == other.max_power && Objects.equals(name, other.name);
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMax_power() {
		return max_power;
	}

	public void setMax_power(int max_power) {
		this.max_power = max_power;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "FavHeros [name=" + name + ", max_power=" + max_power + ", count=" + count + "]";
	}

	@Override
	public int compareTo(FavHeros o) {
		
		return this.max_power-o.getMax_power();
	}
	
	
	
}
