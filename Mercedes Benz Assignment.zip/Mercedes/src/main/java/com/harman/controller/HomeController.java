package com.harman.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ThreadLocalRandom;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.harman.model.Heros;
import com.harman.service.CallService;

@Controller
public class HomeController {
	@Autowired
	private CallService callService;

	Map<String, Heros> map = new HashMap<String, Heros>();
	List<String> CharacterList = new ArrayList<String>();
	Map<String, Heros> dataStorage = new HashMap<String, Heros>();
	List<Heros> namelist = new ArrayList<Heros>();
	List<Heros> limitedHero = new ArrayList<Heros>();
	Map<Heros, Integer> map2 = new HashMap<Heros, Integer>();
	Object[] object = new Object[10];
	Object[] secondArray = new Object[5];

	@RequestMapping(value = "/")
	public ModelAndView test(HttpServletResponse response) throws IOException {
		return new ModelAndView("home");
	}

	@RequestMapping(value = "/home")
	public String hello() {
		return "test";
	}

	@RequestMapping(value = "/characters")
	public void method(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws JsonMappingException, JsonProcessingException {
		callCharacters();
		session = request.getSession();
		session.setAttribute("list", map);

	}

	@Scheduled(fixedRate = 10000)
	public void callCharacters() throws JsonMappingException, JsonProcessingException {

		callService.callCharacters("http://www.mocky.io/v2/5ecfd5dc3200006200e3d64b");
		callService.callCharacters("http://www.mocky.io/v2/5ecfd630320000f1aee3d64d");
		map = callService.callCharacters("http://www.mocky.io/v2/5ecfd6473200009dc1e3d64e");

	}

	/*
	 * public ResponseEntity<String> callCharacters(String uri) throws
	 * JsonMappingException, JsonProcessingException { ModelMap modelMap = new
	 * ModelMap();
	 * 
	 * RestTemplate restTemplate = new RestTemplate(); ResponseEntity<String>
	 * response = restTemplate.getForEntity(uri, String.class); String jsonString =
	 * (String) response.getBody(); JSONObject jsonObject = new
	 * JSONObject(jsonString); System.out.println(jsonObject.getString("name"));
	 * System.out.println(); JSONArray jsonArray =
	 * jsonObject.getJSONArray("character"); System.out.println(jsonArray); for (int
	 * i = 0; i < jsonArray.length(); i++) { JSONObject obj =
	 * jsonArray.getJSONObject(i); String heroName = obj.getString("name"); // int
	 * maxPower = obj.getInt("max_power"); int randomPower =
	 * ThreadLocalRandom.current().nextInt(10, 90 + 1); Heros hero = new
	 * Heros(heroName, randomPower); map.put(heroName, hero);
	 * CharacterList.add(heroName);
	 * 
	 * // System.out.println(obj.getString("name")+" "+obj.getInt("max_power")); }
	 * 
	 * // request.setAttribute("charatcerArrayList", CharacterList); // // for
	 * (Map.Entry<String, Heros> entry : map.entrySet()) { // //
	 * System.out.println("Key: " + entry.getKey()); // System.out.println("Value: "
	 * + entry.getValue()); // }
	 * 
	 * // System.out.println(CharacterList); return null;
	 * 
	 * }
	 */

	@RequestMapping(value = "/saveName", method = RequestMethod.POST)
	public void saveNames(@RequestParam(value = "names") String name, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Heros h= callService.saveNames(request, response, name);
		request.setAttribute("selectedCandidate", object);
		System.out.println(h);
		/*
		 * Heros hero = new Heros(); Heros hero1 = new Heros(); int count = 0; for
		 * (Map.Entry<String, Heros> entry : map.entrySet()) { if
		 * (name.equalsIgnoreCase(entry.getKey())) {
		 * 
		 * hero1 = entry.getValue(); String name1 = hero1.getName(); int power =
		 * hero1.getMax_power(); hero = new Heros(entry.getKey(), power);
		 * limitedHero.add(hero1); } }
		 * 
		 * try {
		 * 
		 * objects = limitedHero.toArray(); System.out.println(objects.length);
		 * System.out.println(limitedHero); for (int len = 0; len < objects.length;
		 * len++) { System.out.println(objects[len]);
		 * request.setAttribute("selectedCandidate", objects[len]); }
		 * 
		 * 
		 * for(int i=0;i<limitedHero.size();i++) {
		 * 
		 * }
		 * 
		 * 
		 * for(Map.Entry<Heros, Integer> entry : map2.entrySet()) {
		 * 
		 * }
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * } catch (Exception e) { System.out.println("Exception Caught!!"); }
		 */
	}

}
