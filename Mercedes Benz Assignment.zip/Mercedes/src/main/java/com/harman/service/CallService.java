package com.harman.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ThreadLocalRandom;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.ast.OperatorPower;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.harman.model.FavHeros;
import com.harman.model.Heros;
import com.mysql.cj.xdevapi.Result;

@Service
public class CallService {
	Map<String, Heros> map = new HashMap<String, Heros>();
	Map<String, FavHeros> favMap = new HashMap<String, FavHeros>();
	List<String> CharacterList = new ArrayList<String>();
	Map<String, Heros> dataStorage = new HashMap<String, Heros>();
	List<FavHeros> namelist = new ArrayList<FavHeros>();
	List<Heros> limitedHero = new ArrayList<Heros>();
	Map<String, Heros> map2 = new HashMap<String, Heros>();
	Object[] objects = new Object[5];
	Object[] secondArray = new Object[5];
	Queue<Heros> queue = new ArrayDeque<Heros>();
	Object[] mapToArray = new Object[5];
	static int min = 0;
	int counterOfChar;
	int countOfChar;

	private Connection getConnection() throws Exception {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/superhero", "root", "root");

		return connection;

	}

	public Map<String, Heros> callCharacters(String uri) throws JsonMappingException, JsonProcessingException {

		ModelMap modelMap = new ModelMap();

//		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
//				.getRequest();

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = restTemplate.getForEntity(uri, String.class);
		String jsonString = (String) response.getBody();
		JSONObject jsonObject = new JSONObject(jsonString);
		// System.out.println(jsonObject.getString("name"));
		// System.out.println();
		JSONArray jsonArray = jsonObject.getJSONArray("character");
		// System.out.println(jsonArray);
		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject obj = jsonArray.getJSONObject(i);
			String heroName = obj.getString("name");
			int maxPower = obj.getInt("max_power");
			// int randomPower = ThreadLocalRandom.current().nextInt(10, 90 + 1);
			Heros hero = new Heros(heroName, maxPower);
			FavHeros favHero = new FavHeros(heroName, maxPower);
			map.put(heroName, hero);
			favMap.put(heroName, favHero);
			CharacterList.add(heroName);

		}
		return map;

	}

	public Heros saveNames(HttpServletRequest request, HttpServletResponse response, String name) throws Exception {
		Heros hero = new Heros(name);
		Heros hero1 = new Heros();
		FavHeros favhero = new FavHeros();
//		Heros hh = new Heros();
		for (Map.Entry<String, Heros> entry : map.entrySet()) {
			if (name.equalsIgnoreCase(entry.getKey())) {

				hero1 = entry.getValue();
				System.out.println(hero1.toString());
				insertInto(hero1);
			}
		}

		return null;
	}

	public void insertInto(Heros hero) {
		if (limitedHero.size() < 15 && min <= 14) {
			if (limitedHero.size() != 0) {
				callList(hero);
			} else {
				limitedHero.add(hero);
			}

		} else {
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>");
			Collections.sort(limitedHero);
			int minimumCount = limitedHero.get(0).getCount();
			int countOnMin = 0;
			for (Heros heroWithMinCount : limitedHero) {
				if (heroWithMinCount.getCount() == (minimumCount)) {
					++countOnMin;
				}
			}
			System.out.println(countOnMin);
			if (countOnMin > 1) {
				Collections.sort(limitedHero, Heros.powerComparator);
				System.out.println(".........................");
				System.out.println(limitedHero);
				limitedHero.remove(0);
			} else {
				limitedHero.remove(0);
			}

			min = min - minimumCount;
			if (limitedHero.contains(hero)) {
				int index = limitedHero.indexOf(hero);
				modify(hero, index);
			} else {
				limitedHero.add(hero);
			}

		}
		System.out.println("/////////////");
		System.out.println("/////////////");
		counterOfChar = 0;
		for (Heros h : limitedHero) {
			countOfChar = h.getCount();
			counterOfChar += countOfChar;
		}
		min = counterOfChar;
		System.out.println("/////////////");
		System.out.println(min);
		System.out.println("/////////////");
		for (int i = 0; i < limitedHero.size(); i++) {
			System.out.println(limitedHero.get(i));
		}

	}

	public void callList(Heros hero) {
		try {
			boolean check = false;
			System.out.println("Call list object:" + hero);

			if (limitedHero.contains(hero)) {
				check = true;
				System.out.println("Check is true");
				int index = limitedHero.indexOf(hero);
				System.out.println("::::::::::::::::::::::::::::::::::::::::::::::::::::");
				Heros heroForModify = limitedHero.get(index);
				System.out.println("Name inside call list is:" + limitedHero.get(index));
				modify(heroForModify, index);
			} else {
				limitedHero.add(hero);
			}

		} catch (Exception e) {
			System.out.println("No elements left!!");
		}

	}

	public void modify(Heros h, int index) {
		System.out.println("Object to be modified is:" + h.toString());
		int count = h.getCount();
		++count;
		System.out.println(index);
		limitedHero.set(index, new Heros(h.getName(), h.getMax_power(), count));

	}

	public void showList() {

		System.out.println("/////////////");
		System.out.println("/////////////");
		counterOfChar = 0;
		for (Heros h : limitedHero) {
			countOfChar = h.getCount();
			counterOfChar += countOfChar;
		}
		min = counterOfChar;
		for (int i = 0; i < limitedHero.size(); i++) {
			System.out.println(limitedHero.get(i));
		}

		System.out.println("/////////////");
		System.out.println(min);
		System.out.println("/////////////");

	}

}
